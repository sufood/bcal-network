# CLAUDE.md — Clinical Data Matching Pipeline

## Project Overview

An R-based clinical data matching pipeline implementing 5 core algorithms for cleaning,
standardising, and linking oncology datasets. All code must be production-grade, auditable,
and reproducible for regulated clinical use.

---

## Environment

- **Language:** R ≥ 4.3.0 (use native pipe `|>` throughout)
- **IDE:** RStudio Desktop ≥ 2023.12 or RStudio Workbench ≥ 2024.04
- **Package management:** `renv` — always run `renv::snapshot()` after adding packages
- **Bioconductor:** `BiocManager` ≥ 1.30.22; release 3.18+ (for `sva`, `limma`, `edgeR`)
- **RAM:** ≥ 16 GB for omics/batch correction modules
- **Lock file:** `renv.lock` must be committed to version control — never skip this step

## Project Structure

```
R/
  01_field_consistency.R      # Null normalisation — regex + fuzzy + TF-IDF
  02_diagnosis_mapping.R      # TNM → AJCC stage — NER + regex grammar + lookup
  03_outlier_detection.R      # MAD + Isolation Forest + LOF
  04_sample_deviation.R       # ComBat + SVA + CUSUM batch correction
  05_patient_history.R        # Fellegi-Sunter record linkage + temporal mining
  utils/
    logging.R                 # Shared audit logger (uses `logger` package)
    validation.R              # Input validators (uses `assertr`)
    hashing.R                 # PII hashing (SHA-256 via `openssl`) — REQUIRED before linkage
data/
  lookup/
    ajcc_staging.rds          # AJCC 8th Ed lookup table, keyed by cancer_type + T + N + M + edition_year
tests/
  testthat/                   # Unit tests for each module
install_packages.R            # Master installer (see Appendix A of requirements)
renv.lock                     # Pinned dependency versions — commit this
```

---

## Module Contracts

### 01 — Field Consistency
- **Input:** Character vector or `data.frame` column, UTF-8
- **Output:** Standardised character/factor with a single canonical null token
- **Pipeline:** regex pre-filter → Jaro-Winkler fuzzy match → TF-IDF cosine fallback
- **Threshold:** Flag matches with confidence < 0.85 as `UNMATCHED_NULL`
- **Throughput targets:** ≥ 1M records/min (vectorised regex); ~100k/min (fuzzy)
- **Key packages:** `stringr`, `stringdist`, `text2vec`, `janitor`, `logger`

### 02 — Diagnosis Mapping
- **Input:** Free-text field containing TNM codes or stage synonyms
- **Output:** Canonical AJCC stage string + source TNM + confidence score
- **Pipeline:** regex grammar parser → AJCC `data.table` keyed lookup → udpipe/spaCy NER fallback → UMLS via `rentrez`
- **Threshold:** Flag confidence < 0.7 as `AMBIGUOUS_TNM`; 1.0 = deterministic parse
- **Critical rule:** Always join on `cancer_type` (ICD-O-3) AND `edition_year` — mismatched editions cause silent staging errors
- **Throughput:** ≥ 500k records/min (regex parser)
- **Key packages:** `stringr`, `re2r`, `data.table`, `udpipe`, `spacyr`, `rentrez`, `assertr`

### 03 — Outlier Detection
- **Input:** Numeric vector; normalise units (mm/cm) before processing
- **Output:** Flag column: `"clean"` | `"soft_outlier"` | `"hard_outlier"` | `"implausible"` + anomaly score
- **Pipeline:** MAD (univariate, per stratum) → Isolation Forest (multivariate) → LOF (density)
- **Thresholds:** MAD > 3.5 or isolation score > 0.6 → `HARD_OUTLIER`
- **Stratification:** Compute thresholds per `cancer_type × stage` — never globally
- **Distribution assumption:** Non-normal, right-skewed — do NOT use SD-based z-scores
- **Throughput:** ≥ 1M rows (MAD); batch ≤ 500k feature matrix (Isolation Forest / LOF)
- **Key packages:** `robustbase`, `isotree`, `dbscan`, `Rlof`, `changepoint`

### 04 — Sample Deviation / Batch Correction
- **Input:** Features × samples omics matrix + metadata (collection site, cancer stage)
- **Output:** Batch-corrected matrix + PERMANOVA R² reduction report + real-time QC flags
- **Pipeline:** ComBat (known batch) → SVA (unknown confounders) → PERMANOVA validation → CUSUM/EWMA real-time SPC
- **Critical rule:** Apply ComBat AFTER log2 transformation and quantile normalisation — never on raw counts
- **Threshold:** CUSUM alarm or PERMANOVA p < 0.05 post-correction → `BATCH_ALERT`
- **Key packages:** `sva` (Bioc), `limma` (Bioc), `edgeR` (Bioc), `vegan`, `umap`, `qcc`, `e1071`, `Rtsne`, `ggplot2`

### 05 — Patient History Cross-Check
- **Input:** Patient records with `patient_id`, `dob`, `name` (hashed), ICD codes, dates
- **Output:** Linked ID pairs + match probability + matched fields + prior history flag
- **Pipeline:** SHA-256 hash PII first → blocking → Fellegi-Sunter EM (reclin2) → TraMineR sequence analysis → arulesSequences ICD trajectory mining
- **Threshold:** Match probability < 0.9 → `REVIEW_LINKAGE`; threshold 0.85 for `select_threshold()`
- **Privacy rule:** NEVER link on raw PII — hash all identifying fields with a salt before any operation
- **Throughput:** ≥ 100k record pairs/min with blocking
- **Key packages:** `reclin2`, `fastLink`, `MatchIt`, `TraMineR`, `arulesSequences`, `igraph`, `tidygraph`, `openssl`, `furrr`

---

## Shared Standards

### Audit Logging
Every match/flag decision must emit a structured log entry containing:
- original value
- canonical form matched to
- algorithm/method used
- confidence score

Use the `logger` package. Wrap shared logging helpers in `R/utils/logging.R`.

### Confidence Scores
All modules return a numeric score in `[0, 1]`. Review thresholds:

| Module | Flag | Threshold |
|---|---|---|
| Field Consistency | `UNMATCHED_NULL` | score < 0.85 |
| Diagnosis Mapping | `AMBIGUOUS_TNM` | confidence < 0.7 |
| Outlier Detection | `HARD_OUTLIER` | MAD > 3.5 or iso > 0.6 |
| Sample Deviation | `BATCH_ALERT` | CUSUM alarm or p < 0.05 |
| Patient History | `REVIEW_LINKAGE` | match prob < 0.9 |

### Input Validation
Use `assertr` to validate inputs at module entry points. Fail loudly with informative messages.

### Privacy
`R/utils/hashing.R` must implement SHA-256 / HMAC hashing via `openssl`. This file must be
loaded before any patient linkage operation. Raw PII fields must never appear in logs, outputs,
or intermediate data frames passed between modules.

### Testing
Write `testthat` tests for each module covering:
- happy path with representative clinical data
- known edge cases (empty strings, all-NA input, single-row input)
- confidence score boundary conditions

---

## Code Style

- Use native pipe `|>` (R ≥ 4.1); avoid `%>%` unless a package requires it
- `snake_case` for all function and variable names
- All functions must have roxygen2 doc comments (`#' @param`, `#' @return`)
- Hard-code nothing — configuration (thresholds, salt, edition year) goes in a named list at the top of each module or a `config.R` file
- Prefer vectorised operations; avoid `for` loops over data frame rows
