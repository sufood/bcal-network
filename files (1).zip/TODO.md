# TODO.md — Clinical Data Matching Pipeline

## Phase 0 — Project Scaffold
- [ ] Run `renv::init()` to initialise reproducible environment
- [ ] Run `install_packages.R` (master installer from requirements Appendix A)
- [ ] Verify all CRAN packages installed at minimum versions
- [ ] Install Bioconductor packages: `BiocManager::install(c("sva", "limma", "edgeR"))`
- [ ] Run `renv::snapshot()` and commit `renv.lock`
- [ ] Create directory structure: `R/`, `R/utils/`, `data/lookup/`, `tests/testthat/`

---

## Phase 1 — Shared Utilities

### Audit Logger (`R/utils/logging.R`)
- [ ] Implement `log_match_decision(original, canonical, method, score)` using `logger`
- [ ] Ensure log output includes timestamp, module name, and all four required fields
- [ ] Write testthat test: verify log entry schema for a sample match

### Input Validation (`R/utils/validation.R`)
- [ ] Implement `validate_character_input(x)` using `assertr` — checks UTF-8, non-NULL
- [ ] Implement `validate_numeric_input(x)` — checks numeric type, rejects Inf
- [ ] Implement `validate_patient_record(df)` — checks required columns exist

### PII Hashing (`R/utils/hashing.R`)
- [ ] Implement `hash_pii(value, salt)` using `openssl::sha256()`
- [ ] Ensure salt is never hard-coded — read from environment variable
- [ ] Write testthat test: same input + salt always produces same hash; different salt produces different hash
- [ ] Document: this file MUST be sourced before any Module 05 operation

---

## Phase 2 — Module 01: Field Consistency

- [ ] Implement regex pre-filter using `stringr::str_detect()` with null variant pattern
- [ ] Implement Jaro-Winkler fuzzy match via `stringdist::stringsim(method = "jw")`
- [ ] Implement TF-IDF cosine fallback using `text2vec`
- [ ] Integrate `janitor::clean_names()` as initial normalisation pass
- [ ] Return confidence score `[0,1]` for every record; flag < 0.85 as `UNMATCHED_NULL`
- [ ] Emit audit log entry for every match decision via `R/utils/logging.R`
- [ ] Write testthat tests:
  - [ ] Known null variants ("NA", "N/A", "not applicable", "-", blank) → canonical token
  - [ ] High-confidence match (score ≥ 0.85) returns no flag
  - [ ] Low-confidence match (score < 0.85) returns `UNMATCHED_NULL` flag
  - [ ] 1M-row benchmark — confirm ≥ 1M records/min for vectorised regex path

---

## Phase 3 — Module 02: Diagnosis Mapping

- [ ] Build AJCC 8th Edition lookup table as `data.table`, keyed on `cancer_type + T + N + M + edition_year`
  - [ ] Save as `data/lookup/ajcc_staging.rds`
  - [ ] Confirm at least one representative cancer type (e.g., C34 lung) is populated
- [ ] Implement TNM regex grammar parser using `stringr::str_match()` with named capture groups
- [ ] Implement `data.table` keyed lookup: always join on `cancer_type` AND `edition_year`
- [ ] Implement R-native NER fallback using `udpipe` (no Python dependency)
- [ ] Implement optional high-accuracy NER via `spacyr` / scispaCy (Python required)
- [ ] Implement UMLS ontology fallback via `rentrez` for unmapped synonyms
- [ ] Validate parsed TNM components against legal value sets using `assertr`
- [ ] Return confidence score: 1.0 (deterministic regex), < 1.0 (NER/fuzzy); flag < 0.7 as `AMBIGUOUS_TNM`
- [ ] Write testthat tests:
  - [ ] Structured TNM string `"T2N0M1"` → correct AJCC stage
  - [ ] Ambiguous synonym → `AMBIGUOUS_TNM` flag emitted
  - [ ] Wrong `edition_year` join → test that it does NOT silently return a wrong stage

---

## Phase 4 — Module 03: Outlier Detection

- [ ] Implement unit normalisation step (mm → cm or vice versa) before any detection
- [ ] Implement univariate MAD outlier detection using `robustbase`; compute per `cancer_type × stage` stratum
- [ ] Implement multivariate Isolation Forest using `isotree`
- [ ] Implement LOF using `dbscan` (or `Rlof` for large datasets)
- [ ] Implement domain hard-limit rules (e.g., tumour size > 300 mm → `implausible`)
- [ ] Implement temporal drift detection using `changepoint`
- [ ] Return flag column: `"clean"` | `"soft_outlier"` | `"hard_outlier"` | `"implausible"` + anomaly score
- [ ] Write testthat tests:
  - [ ] Value within normal range → `"clean"`
  - [ ] Value > 3.5 MAD from stratum median → `"hard_outlier"`
  - [ ] Value > 300 mm → `"implausible"` (hard domain rule, bypasses score threshold)
  - [ ] Single-stratum edge case (all values identical) — must not crash

---

## Phase 5 — Module 04: Sample Deviation / Batch Correction

- [ ] Implement log2 transformation + quantile normalisation step (must run BEFORE ComBat)
- [ ] Implement ComBat batch correction via `sva::ComBat()` with biological covariate model
- [ ] Implement SVA for unknown confounder detection via `sva::sva()`
- [ ] Implement PERMANOVA batch attribution via `vegan::adonis2()` — run before AND after correction
- [ ] Confirm PERMANOVA R² for site decreases after correction; emit `BATCH_ALERT` if not
- [ ] Implement real-time CUSUM control chart via `qcc::cusum()`
- [ ] Implement One-Class SVM for inference-time anomaly detection via `e1071`
- [ ] Implement ComBat-seq for count-based omics (RNA-seq) via `edgeR`
- [ ] Implement PCA + UMAP visualisation coloured by batch/site/biology using `ggplot2` + `umap`
- [ ] Write testthat tests:
  - [ ] Corrected matrix has lower between-site variance than uncorrected
  - [ ] PERMANOVA R² for site is lower post-correction
  - [ ] CUSUM alarm fires on a synthetic drift series

---

## Phase 6 — Module 05: Patient History Cross-Check

- [ ] Source `R/utils/hashing.R` — hash all PII fields BEFORE any linkage step
- [ ] Implement blocking strategy via `reclin2::pair_blocking()` on postcode or similar
- [ ] Implement Fellegi-Sunter EM parameter estimation via `reclin2::problink_em()`
- [ ] Apply match probability threshold: link at ≥ 0.85; flag < 0.9 as `REVIEW_LINKAGE`
- [ ] Implement high-volume alternative path using `fastLink` with parallel processing
- [ ] Implement propensity score matching for cohort construction via `MatchIt`
- [ ] Implement patient temporal sequence analysis via `TraMineR::seqdef()` + `seqdist(method="OM")`
- [ ] Implement ICD code trajectory mining (e.g., diabetes → pancreatic cancer) via `arulesSequences`
- [ ] Build patient history knowledge graph via `igraph` + `tidygraph`
- [ ] Parallelise linkage across blocks using `furrr`
- [ ] Emit full linkage decision log (match weights per field) for regulatory compliance
- [ ] Write testthat tests:
  - [ ] Raw PII never appears in any output data frame or log entry
  - [ ] Known duplicate patient pair → match probability ≥ 0.85
  - [ ] Distinct patients → match probability < 0.5
  - [ ] Known ICD sequence pattern mined correctly by `arulesSequences`

---

## Phase 7 — Integration & QA

- [ ] Wire all 5 modules into a single orchestration script `R/pipeline.R`
- [ ] End-to-end test with synthetic oncology dataset covering all modules
- [ ] Verify all confidence flags propagate correctly to final output
- [ ] Verify audit log is written for every record processed
- [ ] Confirm no raw PII appears anywhere in outputs or logs
- [ ] Run `renv::snapshot()` and confirm `renv.lock` is up to date
- [ ] Document any deviations from minimum package versions in `renv.lock`

---

## Confidence Thresholds — Quick Reference

| Module | Flag | Threshold |
|---|---|---|
| 01 Field Consistency | `UNMATCHED_NULL` | score < 0.85 |
| 02 Diagnosis Mapping | `AMBIGUOUS_TNM` | confidence < 0.7 |
| 03 Outlier Detection | `HARD_OUTLIER` | MAD > 3.5 or iso > 0.6 |
| 04 Sample Deviation | `BATCH_ALERT` | CUSUM alarm or p < 0.05 |
| 05 Patient History | `REVIEW_LINKAGE` | match prob < 0.9 |
